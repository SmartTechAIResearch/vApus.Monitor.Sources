var ID_Copyright = "&copy; 2011 VMware, Inc. All rights reserved.";
var ID_VersionInformation = "Revision 18-Mar-2011 Version 5.0";
